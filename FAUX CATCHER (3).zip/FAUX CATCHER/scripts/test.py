import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import confusion_matrix, roc_curve, auc
import seaborn as sns

def test_and_visualize(model_path, test_dir, input_shape=(224, 224, 3)):
    model = tf.keras.models.load_model(model_path) #Load model
    test_datagen = ImageDataGenerator(rescale=1./255)
    test_generator = test_datagen.flow_from_directory(test_dir,
                                                    target_size=input_shape[:2],
                                                    batch_size=32,
                                                    class_mode='binary',
                                                    shuffle=False)

    loss, accuracy = model.evaluate(test_generator, steps=test_generator.samples // 32)
    print(f"Test Loss: {loss}, Test Accuracy: {accuracy}")

    predictions = model.predict(test_generator, steps=test_generator.samples // 32)
    predicted_classes = (predictions > 0.5).astype(int)
    true_classes = test_generator.classes[:predicted_classes.shape[0]]

    # Visualize results (confusion matrix and ROC curve)
    cm = confusion_matrix(true_classes, predicted_classes)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Real', 'Fake'], yticklabels=['Real', 'Fake'])
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix')
    plt.show()

    fpr, tpr, thresholds = roc_curve(true_classes, predictions)
    roc_auc = auc(fpr, tpr)
    plt.figure(figsize=(8, 6))
    plt.plot(fpr, tpr, label=f'ROC curve (AUC = {roc_auc:.2f})')
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curve')
    plt.legend(loc='lower right')
    plt.show()

# Main execution
model_path = "deepfake_mobilenetv2_regularized.h5"  # Replace with your model path
test_dir = "../cropped_frames/test"
input_shape = (224, 224, 3)

test_and_visualize(model_path, test_dir, input_shape)