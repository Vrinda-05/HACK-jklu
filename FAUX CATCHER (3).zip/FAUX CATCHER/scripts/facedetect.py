# face_detection_preprocessing.py

import cv2
import os
import numpy as np

def detect_and_crop_faces(input_dir, output_dir, selected_images, cascade_path="haarcascade_frontalface_default.xml"):
    """Detects faces in images and crops them, saving the results."""
    face_cascade = cv2.CascadeClassifier(cascade_path)

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for filename in selected_images:
        if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
            input_path = os.path.join(input_dir, filename)
            frame = cv2.imread(input_path)
            if frame is None:
                print(f"Error: Could not read image {input_path}")
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)

            if len(faces) > 0:
                x, y, w, h = faces[0]
                cropped_face = frame[y:y + h, x:x + w]
                roi_area = w * h
                print(f"Detected face in {filename}, ROI area: {roi_area} pixels")
                output_path = os.path.join(output_dir, filename)
                cv2.imwrite(output_path, cropped_face)
            else:
                print(f"No face detected in {filename}")

# Load selected image names
selected_real_images = np.load("selected_real_images.npy")
selected_fake_images = np.load("selected_fake_images.npy")

# Example Usage:
input_real_dir = "../frames/real"
output_real_dir = "../cropped_frames/real"
input_fake_dir = "../frames/fake"
output_fake_dir = "../cropped_frames/fake"

detect_and_crop_faces(input_real_dir, output_real_dir, selected_real_images)
detect_and_crop_faces(input_fake_dir, output_fake_dir, selected_fake_images)