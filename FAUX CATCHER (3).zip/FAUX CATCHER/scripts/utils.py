import cv2

def procImg(p, s=(224, 224), n=True):
    try:
        i = cv2.imread(p)
        if i is None:
            print(f"Error: Could not read image {p}")
            return None
        ir = cv2.resize(i, s)
        if n:
            inorm = ir / 255.0
            return inorm
        else:
            return ir
    except Exception as e:
        print(f"Error processing image {p}: {e}")
        return None