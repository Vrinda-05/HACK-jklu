from utils import procImg
import random
import os
import numpy as np
from featureextract import build_feature_extractor, extract_features


random.seed(42)

rd = "../frames/real"
fd = "../frames/fake"
s = (224, 224)
n = True
sp = 0.052

rf = os.listdir(rd)
ff = os.listdir(fd)

rsz = int(len(rf) * sp)
fsz = int(len(ff) * sp)

rsub = random.sample(rf, rsz)
fsub = random.sample(ff, fsz)

selected_real_images = rsub
selected_fake_images = fsub

d = []
l = []

for f in rsub:
    path = os.path.join(rd, f)
    pi = procImg(path, s, n)
    if pi is not None:
        d.append(pi)
        l.append(0)

for f in fsub:
    path = os.path.join(fd, f)
    pi = procImg(path, s, n)
    if pi is not None:
        d.append(pi)
        l.append(1)

data = np.array(d)
labels = np.array(l)

if data.size > 0:
    print("Data shape:", data.shape)
    print("Labels shape:", labels.shape)
else:
    print("No data was loaded.")

feature_extractor = build_feature_extractor()
features = extract_features(data, feature_extractor)

np.save("selected_real_images.npy", selected_real_images)
np.save("selected_fake_images.npy", selected_fake_images)
