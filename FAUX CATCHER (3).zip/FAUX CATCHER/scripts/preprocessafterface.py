from utils import procImg
import os
import numpy as np
from featureextract import build_feature_extractor, extract_features

rd = "../cropped_frames/real"
fd = "../cropped_frames/fake"
s = (224, 224)
n = True

rf = os.listdir(rd)
ff = os.listdir(fd)

d = []
l = []

for f in rf:
    path = os.path.join(rd, f)
    pi = procImg(path, s, n)
    if pi is not None:
        d.append(pi)
        l.append(0)

for f in ff:
    path = os.path.join(fd, f)
    pi = procImg(path, s, n)
    if pi is not None:
        d.append(pi)
        l.append(1)

data = np.array(d)
labels = np.array(l)

if data.size > 0:
    print("Data shape:", data.shape)
    print("Labels shape:", labels.shape)
else:
    print("No data was loaded.")

feature_extractor = build_feature_extractor()
features = extract_features(data, feature_extractor)

np.save("resnet_features.npy", features)
np.save("resnet_labels.npy", labels)

print("ResNet50 features and labels saved.")