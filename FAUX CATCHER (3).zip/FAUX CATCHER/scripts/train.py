import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout, Input, BatchNormalization, Conv2D
from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras import optimizers
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras import regularizers
from keras_contrib.layers import ConvCapsuleLayer, CapsuleLayer
import os

def build_mobilenetv2_based_model(input_shape=(224, 224, 3), learning_rate=1e-4):
    base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=input_shape)
    for layer in base_model.layers:
        layer.trainable = False

    x = base_model.output
    x = GlobalAveragePooling2D()(x)

    y = Dense(1024, activation='relu', kernel_regularizer=regularizers.l2(0.001))(x)
    y = BatchNormalization()(y)
    y = Dropout(0.5)(y)

    caps1 = ConvCapsuleLayer(32, 16, 3, 2)(y)
    caps2 = CapsuleLayer(16, 1)(caps1)

    predictions = Dense(1, activation='sigmoid')(caps2)

    model = Model(inputs=base_model.input, outputs=predictions)
    return model

def train_model(train_dir, val_dir, epochs=15, batch_size=16, learning_rate=1e-5):
    # Add augmentation to the training data generator
    train_datagen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True
    )
    val_datagen = ImageDataGenerator(rescale=1./255) #No augmentation for validation

    train_generator = train_datagen.flow_from_directory(train_dir,
                                                        target_size=(224, 224),
                                                        batch_size=batch_size,
                                                        class_mode='binary',
                                                        shuffle=True)

    val_generator = val_datagen.flow_from_directory(val_dir,
                                                    target_size=(224, 224),
                                                    batch_size=batch_size,
                                                    class_mode='binary',
                                                    shuffle=False)

    model = build_mobilenetv2_based_model(learning_rate=learning_rate)
    optimizer = optimizers.Adam(learning_rate=learning_rate)
    model.compile(optimizer=optimizer, loss='binary_crossentropy', metrics=['accuracy'])

    early_stopping = EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)

    model.fit(train_generator,
              steps_per_epoch=train_generator.samples // batch_size,
              epochs=epochs,
              validation_data=val_generator,
              validation_steps=val_generator.samples // batch_size,
              callbacks=[early_stopping])
    return model

train_dir = "../cropped_frames/train"
val_dir = "../cropped_frames/val"
test_dir = "../cropped_frames/test"
learning_rate = 1e-5

model = train_model(train_dir, val_dir, learning_rate=learning_rate)

test_datagen = ImageDataGenerator(rescale=1./255)
test_generator = test_datagen.flow_from_directory(test_dir,
                                                  target_size=(224, 224),
                                                  batch_size=32,
                                                  class_mode='binary',
                                                  shuffle=False)

loss, accuracy = model.evaluate(test_generator, steps=test_generator.samples // 32)
print(f"Test Loss: {loss}, Test Accuracy: {accuracy}")

model.save("deepfake_mobilenetv2_capsule.keras")

print("Model training complete. Model saved as deepfake_mobilenetv2_capsule.keras")